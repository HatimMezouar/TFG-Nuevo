<?php
//Ejemplo aprenderaprogramar.com

$nombre = $_GET['id'];

echo $nombre;

