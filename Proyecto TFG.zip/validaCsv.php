<?php

$conexion = mysqli_connect('localhost', 'root', "", 'tfg');


$archivo = fopen("alumne.csv", "r");

$con = 0;


while(($datos = fgetcsv($archivo, ",")) == true) {

    // Lee y muestra los datos del archivo.
    echo "NIA: ".$datos[0]."<br>";
    echo "NOM: ".$datos[1]."<br>";
    echo "COGNOMS: ".$datos[2]."<br>";

    $con++;


    }


?>